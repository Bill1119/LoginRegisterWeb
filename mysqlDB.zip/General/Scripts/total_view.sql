create or replace
algorithm = UNDEFINED view `service_view` as
select
    `u`.`name` as `user_name`,
    `a`.`name` as `activity_name`,
    min(`au`.`occurrence`) as `first_occurrence`,
    max(`au`.`occurrence`) as `last_occurrence`,
    count(0) as `amount`
from
    ((`user` `u`
join `user_activity` `au` on
    (`au`.`activity_id` = `u`.`id`))
join `activity` `a` on
    (`a`.`id` = `au`.`activity_id`))
where
    month(`au`.`occurrence`) = 10
group by
    `au`.`user_id`,
    `au`.`activity_id`
